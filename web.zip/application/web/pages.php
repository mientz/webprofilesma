<?php
//$app->get('/{page:[/^.html]}', function ($req, $res, $args) {
//    return $this->view->render($res, 'web/page.html');
//})->setName('pages');
